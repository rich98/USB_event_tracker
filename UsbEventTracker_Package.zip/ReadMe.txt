UsbEventTracker Packaging Instructions
--------------------------------------

This folder contains the components needed to build a standalone .exe from the PowerShell GUI script.

Files:
- UsbEventTracker.ps1       : Main PowerShell script.
- UsbEventTracker.manifest  : Optional manifest requesting Administrator rights.
- UsbEventTracker.ico       : Optional icon file (provide your own or use default).
- ReadMe.txt                : This file.

Instructions to Build .EXE:
---------------------------

1. Open PowerShell as Administrator.

2. Install ps2exe if not already installed:
   Install-Module -Name ps2exe -Scope CurrentUser

3. Run the following command:
   Invoke-ps2exe -inputFile "UsbEventTracker.ps1" `
                 -outputFile "UsbEventTracker.exe" `
                 -iconFile "UsbEventTracker.ico" `
                 -noConsole `
                 -requireAdmin `
                 -manifest "UsbEventTracker.manifest"

4. The resulting UsbEventTracker.exe can now be run on any compatible Windows machine.

Note:
- You may replace UsbEventTracker.ico with your own icon file.