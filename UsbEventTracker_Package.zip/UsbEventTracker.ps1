Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$usbEventIDs = @(2003, 2004, 2006, 2010, 2100, 2101, 2102, 2103, 2105, 2106)
$logName = "Microsoft-Windows-DriverFrameworks-UserMode/Operational"

$form = New-Object System.Windows.Forms.Form
$form.Text = "USB Event Log Tracker"
$form.Size = New-Object System.Drawing.Size(1000, 820)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::White

$panelTop = New-Object System.Windows.Forms.FlowLayoutPanel
$panelTop.Location = New-Object System.Drawing.Point(10, 10)
$panelTop.Size = New-Object System.Drawing.Size(960, 80)
$panelTop.WrapContents = $true
$panelTop.AutoScroll = $false
$panelTop.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
$form.Controls.Add($panelTop)

$panelBottom = New-Object System.Windows.Forms.FlowLayoutPanel
$panelBottom.Location = New-Object System.Drawing.Point(10, 100)
$panelBottom.Size = New-Object System.Drawing.Size(960, 50)
$panelBottom.WrapContents = $false
$panelBottom.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
$panelBottom.AutoScroll = $false
$form.Controls.Add($panelBottom)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Multiline = $true
$textBox.ScrollBars = "Vertical"
$textBox.Size = New-Object System.Drawing.Size(960, 630)
$textBox.Location = New-Object System.Drawing.Point(10, 160)
$textBox.ReadOnly = $true
$textBox.BackColor = [System.Drawing.Color]::White
$textBox.ForeColor = [System.Drawing.Color]::Black
$form.Controls.Add($textBox)

function Show-USBDrivers {
    $textBox.Text = "Scanning for USB/UAS device drivers..."
    try {
        $drivers = Get-CimInstance Win32_PnPSignedDriver | Where-Object {
            $_.DeviceName -match 'USB|UAS'
        } | Select-Object DeviceName, DriverVersion, Manufacturer, DriverDate

        if ($drivers.Count -eq 0) {
            $textBox.Text = "No USB or UAS drivers found."
        } else {
            $output = $drivers | ForEach-Object {
                "Device: $($_.DeviceName)`nVersion: $($_.DriverVersion)`nProvider: $($_.Manufacturer)`nDate: $($_.DriverDate)`n"
            }
            $textBox.Lines = $output
        }
    } catch {
        $textBox.Text = "Error retrieving drivers: $($_.Exception.Message)"
    }
}

function Show-Events {
    param([int[]]$FilterIDs)

    $output = @()
    $textBox.Text = "Scanning event log..."

    try {
        foreach ($eventID in $FilterIDs) {
            $events = Get-WinEvent -LogName $logName -FilterXPath "*[System[(EventID=$eventID)]]" -ErrorAction SilentlyContinue
            foreach ($event in $events) {
                $entry = "[{0}] Event ID: {1} - {2}" -f $event.TimeCreated, $event.Id, $event.Message
                $output += $entry
            }
        }

        $textBox.Lines = if ($output.Count -eq 0) { "No matching events found." } else { $output }
    } catch {
        $textBox.Text = "An error occurred while scanning event logs.`r`n$($_.Exception.Message)"
    }
}

function Set-DarkMode {
    $form.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $textBox.BackColor = [System.Drawing.Color]::Black
    $textBox.ForeColor = [System.Drawing.Color]::White
    $panelTop.BackColor = $form.BackColor
    $panelBottom.BackColor = $form.BackColor

    foreach ($ctrl in $form.Controls + $panelTop.Controls + $panelBottom.Controls) {
        if ($ctrl -is [System.Windows.Forms.Button] -or $ctrl -is [System.Windows.Forms.Label]) {
            $ctrl.BackColor = $form.BackColor
            $ctrl.ForeColor = [System.Drawing.Color]::White
        }
    }
}

function Set-LightMode {
    $form.BackColor = [System.Drawing.Color]::White
    $textBox.BackColor = [System.Drawing.Color]::White
    $textBox.ForeColor = [System.Drawing.Color]::Black
    $panelTop.BackColor = $form.BackColor
    $panelBottom.BackColor = $form.BackColor

    foreach ($ctrl in $form.Controls + $panelTop.Controls + $panelBottom.Controls) {
        if ($ctrl -is [System.Windows.Forms.Button] -or $ctrl -is [System.Windows.Forms.Label]) {
            $ctrl.BackColor = $form.BackColor
            $ctrl.ForeColor = [System.Drawing.Color]::Black
        }
    }
}

$btnAll = New-Object System.Windows.Forms.Button
$btnAll.Text = "Show All Events"
$btnAll.Size = New-Object System.Drawing.Size(110, 30)
$btnAll.Add_Click({ Show-Events -FilterIDs $usbEventIDs })
$panelTop.Controls.Add($btnAll)

foreach ($id in $usbEventIDs) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = "Event $id"
    $btn.Size = New-Object System.Drawing.Size(80, 30)
    $btn.Add_Click([ScriptBlock]::Create("Show-Events -FilterIDs @($id)"))
    $panelTop.Controls.Add($btn)
}

$btnClear = New-Object System.Windows.Forms.Button
$btnClear.Text = "Clear Console"
$btnClear.Size = New-Object System.Drawing.Size(110, 30)
$btnClear.Add_Click({ $textBox.Clear() })
$panelBottom.Controls.Add($btnClear)

$btnCopy = New-Object System.Windows.Forms.Button
$btnCopy.Text = "Copy to Clipboard"
$btnCopy.Size = New-Object System.Drawing.Size(130, 30)
$btnCopy.Add_Click({ [System.Windows.Forms.Clipboard]::SetText($textBox.Text) })
$panelBottom.Controls.Add($btnCopy)

$btnLight = New-Object System.Windows.Forms.Button
$btnLight.Text = "Light Mode"
$btnLight.Size = New-Object System.Drawing.Size(100, 30)
$btnLight.Add_Click({ Set-LightMode })
$panelBottom.Controls.Add($btnLight)

$btnDark = New-Object System.Windows.Forms.Button
$btnDark.Text = "Dark Mode"
$btnDark.Size = New-Object System.Drawing.Size(100, 30)
$btnDark.Add_Click({ Set-DarkMode })
$panelBottom.Controls.Add($btnDark)

$btnDrivers = New-Object System.Windows.Forms.Button
$btnDrivers.Text = "Show Drivers"
$btnDrivers.Size = New-Object System.Drawing.Size(110, 30)
$btnDrivers.Add_Click({ Show-USBDrivers })
$panelBottom.Controls.Add($btnDrivers)

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::Run($form)